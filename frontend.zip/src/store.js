import { legacy_createStore, combineReducers, applyMiddleware } from "redux";

import thunk from "redux-thunk";

import {
  productListReducer,
  productDatailReducer,
} from "./reducer/productListReducer";
import { cartReducer } from "./reducer/cartReducer";

const reducer = combineReducers({
  productList: productListReducer,
  productDetail: productDatailReducer,
  cart: cartReducer, //pass to cartAction
});
const cartItemsFromLocalStorage = localStorage.getItem("cartItems")
  ? JSON.parse(localStorage.getItem("cartItems"))
  : [];

const initialState = {
  cart: { cartItems: cartItemsFromLocalStorage },
};

const middleware = [thunk];

const store = legacy_createStore(
  reducer,
  initialState,
  applyMiddleware(...middleware)
);

export default store;
