import React from "react";

import { LinkContainer } from "react-router-bootstrap";

import { Container, Navbar, Nav } from "react-bootstrap";

import { IconContext } from "react-icons";

import { FaShoppingCart } from "react-icons/fa";

import { VscAccount } from "react-icons/vsc";

import "./Header.css";

export const Header = () => {
  return (
    <IconContext.Provider value={{ size: "1.5rem", className: "icon" }}>
      <header>
        <Navbar className="My-Nav" variant="dark">
          <Container fluid className="icon">
            <LinkContainer to="/">
              <Navbar.Brand>مارکت من</Navbar.Brand>
            </LinkContainer>
            <Nav className="navItems">
              <LinkContainer to="/cart">
                <Nav.Link>
                  <FaShoppingCart />
                </Nav.Link>
              </LinkContainer>
              <LinkContainer to="/account">
                <Nav.Link>
                  <VscAccount />
                </Nav.Link>
              </LinkContainer>
            </Nav>
          </Container>
        </Navbar>
      </header>
    </IconContext.Provider>
  );
};
