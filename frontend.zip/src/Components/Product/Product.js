import React from "react";

import { Card } from "react-bootstrap";

import { Link } from "react-router-dom";

import "./Product.css";

export const Product = (props) => {
  return (
    <div>
      <Card className="my-card  rounded">
        <Link to={`/product/${props.product._id}`}>
          <Card.Img src={props.product.image} variant="top" />
        </Link>
        <Card.Body>
          <Link to={`/product/${props.product._id}`}>
            <Card.Title as="div" style={{ textAlign: "center" }}>
              {props.product.name}
            </Card.Title>
          </Link>
        </Card.Body>
        <Card.Text as="h3">{props.product.price}</Card.Text>
      </Card>
    </div>
  );
};
