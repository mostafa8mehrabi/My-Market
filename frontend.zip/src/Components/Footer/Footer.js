import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { Link } from "react-router-dom";

import { FaLinkedin, FaGithub } from "react-icons/fa";
import { IconContext } from "react-icons";

import "./Footer.css";

export const Footer = () => {
  return (
    <IconContext.Provider value={{ size: "1.5rem", className: "react-icons" }}>
      <footer>
        <Container fluid>
          <Row className="row1 px-3">
            <Col xs={10} lg={6} sm={12}>
              لینک های ارتباطی
            </Col>
            <Col lg={6} sm={12}>
              <Link to="https://www.linkedin.com/in/mostafa-mehrabi/">
                <FaLinkedin />
              </Link>
              <Link to="https://github.com/mostafa8mehrabi">
                <FaGithub />
              </Link>
            </Col>
          </Row>
          <Row className="row2 px-3">
            <Col lg={6} sm={12}>
              نشانی : تهران - خیابان ایرانشهر شمالی
            </Col>
          </Row>
        </Container>
      </footer>
    </IconContext.Provider>
  );
};
