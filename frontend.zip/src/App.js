import "./App.css";

import React from "react";

import { Header } from "./Components/Header/Header";

import { Container } from "react-bootstrap";

import Home from "./pages/Home";

import { ProductDescription } from "./pages/ProductDescription";

import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import { Footer } from "./Components/Footer/Footer";
import { Cart } from "./pages/Cart";

const App = () => {
  return (
    <Router className="App">
      <Header />
      <main>
        <Container>
          <Routes>
            <Route path="/" exact element={<Home />} />
            <Route path="/product/:id" element={<ProductDescription />} />
            <Route path="/cart/:id?" element={<Cart />} />
          </Routes>
        </Container>
      </main>
      <Footer />
    </Router>
  );
};

export default App;
