import React, { useEffect } from "react";

import { useDispatch, useSelector } from "react-redux";

import { Link, useNavigate, useParams } from "react-router-dom";

// import axios from "axios";

import { Row, Col, Image, ListGroup } from "react-bootstrap";

import { productDetailAction } from "../action/productAction";

export const ProductDescription = (props) => {
  // read from  products from "../products";
  // const selectedProduct = products.find((item) => {
  //   return item._id === id;
  // });

  // const [product, setProduct] = useState({});
  // const { id } = useParams();

  // useEffect(() => {
  //   const sendRequest = async () => {
  //     const response = await axios.get(
  //       `http://localhost:8000/api/products/${id}`
  //     );
  //     setProducts(response.data);
  //   };
  //   sendRequest();
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [id]);
  const { id } = useParams();
  const navigate = useNavigate();

  const dispatch = useDispatch();
  const productDetail = useSelector((state) => state.productDetail);
  const { loading, product } = productDetail;

  useEffect(() => {
    dispatch(productDetailAction(id));
  }, [dispatch, id]);

  const addToCartHandler = () => {
    navigate(`/cart/${id}`); //id is exracted from useParams
  };
  return (
    <div>
      <Row>
        <Col xs={8} lg={10} md={8} sm={12}>
          <Link to="/" className="btn btn-outline-dark my-3 ">
            بازگشت به صفحه اصلی
          </Link>
        </Col>
        <Col lg={2} md={4} sm={12} className="text-left">
          <button
            onClick={addToCartHandler}
            type="button"
            className="btn btn-outline-dark my-3 "
          >
            افزودن به سبد خرید
          </button>
        </Col>
      </Row>
      {loading ? (
        <p>در حال دریافت اطلاعات ...</p>
      ) : (
        <Row>
          <Col md={3}></Col>
          <Col md={3}>
            <ListGroup variant="flush" className="my-5">
              <ListGroup.Item>
                <h3>{product.name}</h3>
              </ListGroup.Item>
              <ListGroup.Item>{product.description}</ListGroup.Item>
              <ListGroup.Item>{product.price}</ListGroup.Item>
            </ListGroup>
          </Col>
          <Col md={6}>
            <Image src={product.image} fluid />
          </Col>
        </Row>
      )}
    </div>
  );
};
