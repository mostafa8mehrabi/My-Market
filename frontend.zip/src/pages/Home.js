import React, { useEffect } from "react";
// import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { Product } from "../Components/Product/Product";
import { Row, Col } from "react-bootstrap";
import { productListAction } from "../action/productAction";

const Home = () => {
  // const [products, setProducts] = useState([]);
  // useEffect(() => {
  //   const sendRequest = async () => {
  //     const response = await axios.get("http://localhost:8000/api/products");
  //     setProducts(response.data);
  //   };
  //   sendRequest();
  // }, []);
  const dispatch = useDispatch();

  const productList = useSelector((state) => state.productList); //productList is in reducerombiner
  const { loading, products } = productList;
  useEffect(() => {
    dispatch(productListAction());
  }, [dispatch]);
  return (
    <div>
      <h2>محصولات</h2>
      <hr />
      {loading ? (
        <p>در حال دریافت محصولات</p>
      ) : (
        <Row>
          {products.map((item) => {
            //map in static list
            return (
              <Col key={item._id} sm={12} md={6} lg={4}>
                <Product product={item} />
              </Col>
            );
          })}
        </Row>
      )}
    </div>
  );
};
export default Home;
