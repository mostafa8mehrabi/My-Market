import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { addToCart, removeFromCart } from "../action/cartAction";
import { Row, Col, Image, ListGroup, Button, Card } from "react-bootstrap";

import { FaTrash } from "react-icons/fa";
import "./Cart.css";

export const Cart = () => {
  const { id } = useParams();
  const cart = useSelector((state) => state.cart);

  const { cartItems } = cart;
  console.log(cartItems);

  const dispatch = useDispatch();
  useEffect(() => {
    if (id) dispatch(addToCart(id));
  }, [dispatch, id]);

  const removeFromCartHandler = (id) => {
    dispatch(removeFromCart(id));
  };
  return (
    <div className="two-major-column">
      <Col sm={8}>
        <h4>سبد خرید</h4>
        {cartItems.length === 0 ? (
          <p>سبد خرید خالی است😢</p>
        ) : (
          <div>
            <ListGroup variant="flush">
              <ListGroup.Item>
                <Row className="column center">
                  <Col md={2} sm={2}>
                    <p className="my-title">تصویر</p>
                  </Col>
                  <Col md={3} sm={2}>
                    نام
                  </Col>
                  <Col md={2} sm={2}>
                    <p>قیمت </p>
                  </Col>
                  <Col md={2} sm={2}>
                    حذف
                  </Col>
                  <hr />
                </Row>
              </ListGroup.Item>
            </ListGroup>
            <ListGroup variant="flush">
              {cartItems.map((item) => (
                <ListGroup.Item key={item.id}>
                  <Row className="column">
                    <Col md={2} sm={2} className="center">
                      <Image src={item.image} alt={item.name} fluid rounded />
                    </Col>
                    <Col md={3} sm={2} className="center">
                      {item.name}
                    </Col>
                    <Col md={2} sm={2} className="center">
                      {item.price}
                    </Col>
                    <Col md={2} sm={2} className="center">
                      <Button
                        type="button"
                        variant="light"
                        onClick={() => removeFromCartHandler(item.id)}
                      >
                        <FaTrash />
                      </Button>
                    </Col>
                  </Row>
                </ListGroup.Item>
              ))}
            </ListGroup>
          </div>
        )}
      </Col>
      <Col sm={4}>
        <Card>
          <ListGroup variant="flush" className="center">
            <ListGroup.Item sm={4}>
              قیمت کل: &nbsp;
              {cartItems.reduce((acc, item) => acc + item.price, 0)}
            </ListGroup.Item>
          </ListGroup>
        </Card>
      </Col>
    </div>
  );
};
