const products = [
  {
    _id: "1",
    name: "Airpods",
    image: "/images/airpods.jpg",
    description: "توضیحات محصول",
    price: 99,
  },
  {
    _id: "2",
    name: "Apple Watch",
    image: "/images/apple-watch.jpg",
    description: "توضیحات محصول",
    price: 79,
  },
  {
    _id: "3",
    name: "iPhone 12",
    image: "/images/iphone-12.jpg",
    description: "توضیحات محصول",
    price: 89,
  },
  {
    _id: "4",
    name: "iPhone SE",
    image: "/images/iphone-se.jpg",
    description: "توضیحات محصول",
    price: 29,
  },
  {
    _id: "5",
    name: "MacBook Pro",
    image: "/images/macbook.jpg",
    description: "توضیحات محصول",
    price: 89,
  },
  {
    _id: "6",
    name: "Logitech MX Master",
    image: "/images/mouse.jpg",
    description: "توضیحات محصول",
    price: 59,
  },
];

module.exports = products;
